# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a
Changelog](https://keepachangelog.com/en/1.0.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.5.14]
### Added (Wetwired etiquette, p27)
- Wetwired character sheets have an Etiquette table on the Skills tab,
  between Careers and Adventuring Skills. It lists each etiquette the
  character's careers grant, rated at that career's career skill. When two
  careers grant the same etiquette, the higher career skill counts. Click an
  etiquette to roll a test (the dialog takes modifiers such as a contact's
  +4). Warlock! and Warpstar! sheets are unchanged.
- Careers can grant more than one etiquette: the career sheet has "Also
  grants" toggles under the main etiquette. A career that offers a choice
  shows only those etiquettes in its dropdown, marked "Choose one".
- Career chat cards list the career's etiquette(s) in Wetwired.

### Fixed
- Four Wetwired careers had lost an etiquette because a career could hold
  only one: Detective (Street and Corporate), Dilettante (Corporate and
  Media), Tribal Blockser (Street and Tribal), and Physical Adept (Street or
  Corporate, player's choice). The compendium entries are fixed. On world
  load, copies already in the world or on characters get the missing
  etiquette once. Careers a GM has already given extra etiquettes are left
  alone.

## [2.5.13]
### Added
- Warpstar!: Talent Table 1 and Talent Table 2 as d20 rollable tables, one
  result per talent with its full rules text (p16-24).
- Warpstar!: the four Basic Careers d6 columns, each result linking to its
  career in the compendium; the sixth result of column 4 is "You choose!"
  (p33).
- Warlock!: the four Basic Careers d6 columns, linked to the careers
  compendium (p20-21).
- Warlock!: Starting Spell table for Wizard's Apprentices and Initiates. It
  rolls (1d6-1)*6+1d6, which gives the same odds as the book's two d6, and
  each result shows the die pair and links to the spell (p96-97).

### Fixed (Warpstar! compendia checked against the book)
- Slug pistol damage 1d6 -> 1d6+1 (S1d6+1P, p109).
- Bounty Hunter: Stealth 12 -> Streetwise 12 (p38).
- Investigator: Sleight of hand 10 -> Streetwise 10 (p50).
- Stessel Nightwing: heavy prod gun 2d6+2 -> 2d6+1 (S2d6+1S, p137).
- Checked with no changes needed: the other 15 weapons, 3 armours, the
  other 21 basic and all 13 advanced careers (skills, maximums and equipment
  damage codes), all 36 glyphs (cost, standard/opposed and text), all 18
  denizens, 11 abilities, the other 20 vehicles, and the Warp Bleed and both
  mutation tables.

## [2.5.12]
### Added (Wetwired compendia, from the book)
- Weapons (29): melee, pistols, SMGs, rifles, shotguns, assault rifles, heavy
  weapons and explosives, with damage, critical type, ammo, fire modes,
  concealment and Resource cost (p161-165).
- Armour (7) with layers, penalty and concealment (p167); Equipment (6):
  weapon accessories and ammo (p161, p166).
- Cyberware (43 headware and bodyware, p150-154), Cyberdecks (6) and
  Programs (6) (p143-144, p169).
- Careers: 24 basic (p30-77) and 16 advanced (p87-102), with skill maximums,
  etiquette, equipment or requirement, and background tables.
- Spells (28, p137-142), Contacts (54, p194-198), Creature Abilities (13,
  p174-177) and Bestiary (14, p178-193).
- Rollable tables: six critical tables (p116-122), Miscast (p136), Ancestry
  (2d6, p17) and the four basic career columns (p28), linked to the careers.
- Critical macros for the six Wetwired damage types.
- Wetwired criticals and miscasts now use these tables, and new Wetwired
  characters get the Wetwired unarmed weapon.

### Fixed
- Skill columns on character and career sheets are balanced for any number
  of skills (Wetwired's 27 split 14/13 instead of 16/11).
- Warpstar! critical tables roll at least 2d6+1, as a critical always adds
  at least 1.

### Notes
- Book misprints corrected: misnumbered background tables (Bodyguard, Thief,
  Former Salaryman) are numbered by position; "tAncestry"/"disgAncestry"
  read as "trace"/"disgrace".
- The book gives no critical letter for the Heavy Machine Gun, Rocket
  Launcher or C5 Plastic Explosives; their damage type is left blank.

## [2.5.11]
### Added (Wetwired)
- Item types: Cyberware (headware or bodyware, points, installed), Cyberdeck
  (quality), Program (type, rating) and Contact (etiquette, role), each with
  its own sheet. Characters list cyberware and matrix gear on the Gear tab and
  contacts on the Notes tab.
- Weapons: ammo, magazine, fire modes, concealment and Resource cost. Armour:
  layers, penalty, concealment, Resource cost and "stops concussive damage".
  Equipment: Resource cost. Careers: etiquette.
- Characters: ancestry (choose or roll 2d6) with allergy, and Wealth Points
  replacing coins. Resource roll button: d20 + Wealth against the cost, 1
  Wealth spent for trying, with the option to pay the shortfall (p155-156).
- Cyberware budget: each Cybertech level above 4 buys a point in its
  category (p148); the Gear tab shows used and available points.

### Changed (Wetwired rules, via the per-game config)
- Ranged attackers get +5; close range is -5 as well as faraway (p107).
- Fire modes: burst -3, full auto -6 to hit (p165).
- Armour layers: every equipped piece rolls its reduction and they add
  (p112). Concussive damage ignores armour unless it stops concussive (power
  armour, p109).
- Ancestry: Dwarf +1 Dodge, Ork +1 melee and -1 ranged, Troll -2 Dodge and
  +2 melee are applied in combat (p18).
- Casting: -2 per full point of installed cyberware (p133, p149); a natural 1
  costs the stamina again (p134).

### Fixed
- Sheet names in Foundry's sheet picker were showing raw keys.

Warlock! and Warpstar! are unchanged: combat results and item choices were
checked against 2.5.10.

## [2.5.10]
### Fixed
- Criticals use each game's dice: 1d6 in Warlock!, 2d6 in Warpstar! and
  Wetwired, plus the stamina below 0. The result text comes from the game's
  compendium tables (exact book wording, clickable rolls); totals above 10
  take the 10+ result. Wetwired uses the Warlock! text until it has tables.
- Warpstar! miscasts roll on the Warp Bleed table, adding the glyph's stamina
  cost to the d20 (p152); results above 20 take result 20. Results 18 and 19
  roll on the Lesser or Greater Mutations table.
- Wetwired damage types are its own: slashing, piercing, blunt, concussive,
  energy and matrix (p109). Its "Small Arms" weapon skill is now "Small arms",
  matching the skill list, so Wetwired guns use the character's skill and
  count as ranged. Existing Wetwired weapons are updated on world load
  (Small Arms to Small arms, Crushing to Blunt).
- Warpstar! critical tables: every total of 10 or more lands on the 10+
  result (11 and 12 drew nothing before).
- Warpstar! critical macros rebuilt for v14 and roll 2d6 (they rolled 1d6).

### Added
- Warpstar! "Critical - Ship" (p126) and "Critical - Vehicle" (p148) tables,
  with macros. Ship-damage weapons use the ship table.

## [2.5.9]
### Changed
- New per-game rules config (`module/config/systems.mjs`) for Warlock!,
  Warpstar! and Wetwired: weapon types, damage types, weapon skills, ranged
  skills, the unarmed weapon, shield and pin/flank options, casting skills and
  vehicle skill tests. The items, actors, sheets, rolls and skill-test dialog
  read it instead of branching on the game's name. No change in behaviour:
  item choices, ranged detection, skill lookups, casting skill and the dialog
  were checked against 2.5.8 for all three games.

## [2.5.8]
### Changed
- The skill "+" button (shown only while advances remain) now appears only
  for skills of the active career that are below that career's maximum
  (Warlock! p60-61); the cap of 6 for other skills is gone. Skills already
  above the maximum keep their level. The tooltip shows the next level and the
  maximum, and the action itself refuses any other advance.

## [2.5.7]
### Fixed
- A natural 1 on a casting test now always fails the spell, whatever the
  total (Warlock! p92; same rule in Warpstar! and Wetwired). The second test
  only decides whether it miscasts.
- The skill "+" button only appears when an advance is available and the skill
  is below its cap: the active career's maximum for that career's skills, or 6
  for any other skill.

## [2.5.6]
### Fixed
- Warlock! spells: Armour and Enchant cost 3 stamina, as in the book (p98, p101).
- Warlock! bestiary: the Ghoul's Hide armour is equipped, so its 1d3 reduction
  applies in combat.
- Warlock! critical tables roll at least 1d6+1 (a critical always adds the
  stamina below 0), and every total of 10 or more lands on the "dead" result.
- Warlock! critical macros rebuilt for Foundry v14 (DialogV2, no jQuery). They
  ask for the stamina below 0 (minimum 1), roll 1d6 plus that amount, and draw
  from a world copy of the table or, failing that, the system compendium.

## [2.5.5]
### Added
- All actor and item sheets are resizable: drag the bottom-right corner. The
  header and tabs keep their size, and the sheet body fills the window and
  scrolls when the sheet is made smaller.

### Fixed
- Template preloading uses `foundry.applications.handlebars.loadTemplates`
  (the global was deprecated in v13 and is removed in v15).

## [2.5.4]
### Fixed
- Sheet header resource blocks share the row evenly and wrap long labels, so
  the Monster sheet's Actions per Round, Weapon Skill and Adventuring Skills
  no longer overlap.
- Header resource boxes line up on one row; the Character sheet's rest buttons
  sit below Stamina instead of pushing Luck and Actions per Round down.
- Sheet registration uses `foundry.applications.apps.DocumentSheetConfig`
  (the global was deprecated in v13 and is removed in v15).

## [2.5.3]
### Fixed
- Character and Career sheets always show the active subsystem's full
  predefined skill list (Warlock!, Warpstar! or Wetwired), sorted by name,
  even when the stored data is missing some or all skills.
- On world load the GM client adds any missing active-subsystem skills to
  Characters (at level 4), their Careers and world Career items. Existing
  levels and skills from other subsystems are left untouched.
- Skill tests, skill increments, vehicle tests and career level calculation no
  longer break on a missing skill entry.

## [2.5.2]
### Fixed
- Foundry v14 / ApplicationV2 compliance pass across all sheets:
  - Sheet templates no longer nest a `<form>` inside the sheet's own form, so
    field edits save again.
  - Tabs use the AppV2 tab action and active classes; removed the custom
    `_getTabs()` helpers that overwrote Foundry's tab context.
  - Rich-text fields use `<prose-mirror>` instead of the removed `{{editor}}`
    helper, and enriched HTML is no longer written back into live actor/item
    data.
  - Portrait editing uses the built-in `editImage` action.
  - Item and effect rows are draggable via ActorSheetV2's built-in DragDrop.
  - Active Effects use `name`/`img` instead of the removed `label`/`icon`.
  - Chat cards no longer pass the removed `CONST.CHAT_MESSAGE_TYPES`.
- Dialogs read their fields from `button.form`; dialog templates no longer wrap
  content in a nested `<form>`.
- Combat tracker extends `foundry.applications.sidebar.tabs.CombatTracker`, and
  the side-turn banner, action badges and settings blurb use the
  `renderCombatTracker` / `renderSettings` hooks.

## [2.5.1]
### Fixed
- Added `TYPES.*` localization keys for sheet titles.
- Guarded against characters with no adventuring skills.

## [2.4.3]
### Added
- **Integrated combat workflow**: Click the attack icon on any weapon to run a
  fully automated opposed combat resolution — attacker roll, defender
  counter-roll (weapon skill for melee, Dodge for ranged), damage, armour
  reduction, stamina application, all in a single chat card.
- **Mighty strike detection**: Automatically detected when the winner's total is
  three or more times the loser's total. Damage is doubled per the rules.
- **Critical hit automation**: When stamina drops below 0, the system auto-rolls
  1d6 + negative stamina on the correct critical table (Slashing, Piercing,
  Crushing, or Blast) and displays the full result text. Includes a "Pull
  Critical" button to set the target to 0 stamina instead.
- **Melee counter-attacks**: In melee, if the defender wins the opposed test,
  their weapon damage is rolled and applied to the attacker — matching the
  Warlock! rules where either combatant can be injured.
- **Attack setup dialog**: Choose weapon (if multiple equipped), target (if
  multiple targeted with stamina shown), modifier, faraway, defender shield,
  flanking/pinned options.
- **Fallback attack card**: When no tokens are targeted, a simpler card is shown
  with manual "Apply Damage" and "Apply Half Damage" buttons.
- **Miscast / Wrath of the Otherworld**: Casting spells now detects a natural 1
  on the Incantation test, auto-rolls a second saving test, and if that fails,
  rolls 1d20 on the full miscast table (all 20 entries from the rulebook).
  Everything appears in a single chat card.
- **Automatic stamina cost deduction**: Spell stamina cost is deducted before
  the casting test, with an insufficient stamina check.
- **Luck auto-deduction**: Testing Luck now automatically deducts 1 from the
  current Luck value regardless of success or failure, per the rules.
- **Short rest**: Mug icon beneath Stamina — recovers half of lost stamina.
- **Long rest**: Bed icon beneath Stamina — recovers all stamina to maximum.
- Both rest actions post a summary to chat.
- All four critical hit tables embedded (Slashing, Piercing, Crushing, Blast).
- All 20 miscast table entries embedded.

### Changed
- **Warlock! theme overhaul**: Subsystem CSS now uses Cinzel (headings) and
  Crimson Pro (body) fonts via Google Fonts import, matching the angular
  medieval heading style and clean serif body text of the Traitor's Edition
  rulebook. Flat pale parchment background, thin hairline table rules, clean
  tab underlines, no glow effects — faithful to the book's stark
  ink-on-parchment aesthetic.
- Default new Character stamina set to 14/14 and Luck to 8/8 (the minimum
  possible at character creation) instead of 0/0.
- Spell test handler updated to use the new `rollSpellTest` flow instead of a
  plain skill test.
- Repository moved from GitLab to GitHub. Manifest and download URLs updated
  accordingly.

## [2.2.2]
### Added
- Side-based initiative with alternating turns and GM combatant selection.
- Actions-per-round tracking in the combat tracker with visual badges.
- Subsystem-specific CSS theming (Warlock!, Warpstar!, Wetwired) via body class
  and CSS custom properties.
- Wetwired subsystem support (skills, weapon types, damage types, combat
  options).

### Changed
- Updated to Foundry VTT v13 compatibility.
- Combat tracker hides irrelevant controls and shows side turn/round start info.

## [1.0.0]
### Added
- Support for Passions optional rule from Compendium 2.
- All Warpstar! compendia.
- Confirmation dialog before deleting items.
- Actions per round sheet counter for Characters.
- Abilities for Monsters.
- Functionality to assign and roll Monster Weapon Skill for weapons.
- Convenient skill test dialog controls.
- Ability to roll from a Vehicle sheet and incorporate its modifiers into the
  roll.
- Combat tab to show equipped weapons, equipped armour, and critical effects.

### Changed
- Simplified logic and reduced redundancy across the system.
- Made skills static once document is created.
- Organized localization file structure.
- Increased localization across system.
- Made actions per round a counter on Monster sheets.
- Combat tracker combatants are now color coded and sorted by token disposition.

### Fixed
- Changed Sleep stamina cost to 3 instead of 4.
- Changed Warpstar! "Heavy" weapon type to "Large".
- Increased migration version so that it runs properly.
- Added functionality to migrate pack actor items.

### Removed
- Notes for Monsters (replaced by abilities).

## [0.3.10]
### Changed
- Career level calculations for Warlock!
- Stamina cost for Blast, Foulness, and Sleep.
- Roll for critical tables.

### Fixed
- Career levels not calculating when a skill is advanced.

## [0.3.9]
### Fixed
- Compounding roll modifiers.

## [0.3.8]
### Added
- Compendia for Warlock!.

## [0.3.7]
### Added
- Doc-strings and comments across codebase.
- Updates to CHANGELOG.md.
- Ability to modify equipment quantities by left-clicking and right-clicking.
- Compendium migration functionality.

### Changed
- Changed Main tab name to Skills.
- Made various small refactors.
- Changed display of combatants in combat tracker with no actions left.
- Updated chat cards for items to display additional information.

## [0.3.6]
### Added
- Ability to roll 2d6+Pluck from the sheet.

### Fixed
- Modified roll chat messages to show the actor as the speaker instead of the
  user.

## [0.3.5]
### Added
- Doc-strings and comments across codebase.

## [0.3.6]
### Added
- Ability to roll 2d6+Pluck from the sheet.

### Fixed
- Modified roll chat messages to show the actor as the speaker instead of the
  user.

## [0.3.5]
### Added
- Doc-strings and comments across codebase.

## [0.3.4]
### Fixed
- Fix unarmed attack weapon to only be added to characters.

## [0.3.3]
### Added
- Unarmed attack weapon for all new characters.

### Fixed
- Fix monster Adventuring Skills rolls.

## [0.3.2]
### Fixed
- Fix faulty permission check in combat tracker.

## [0.3.1]
### Fixed
- Fix display of actions-per-round for non-GMs.

## [0.3.0]
### Added
- Rudimentary migration scripts.
- Rudimentary combat tracker.

## [0.2.1]
### Added
- Stamina cost field for spells and glyphs.

### Changed
- Update formatting of actor portraits.
- Refactor tables.

### Fixed
- Fix item descriptions not being enriched.
- Add missing dialog file for stamina costs.

## [0.2.0]
### Changed
- Update user interface across all system components.

## [0.1.9]
### Fixed
- Fix monster spells and glyphs not appearing on sheets.

## [0.1.8]
### Fixed
- Add missing super call in item sheet activateListeners().

## [0.1.7]
### Added
- Spells and glyphs to monster sheets.

### Changed
- Add jQuery listener to input elements to select all contents when
  focused.

## [0.1.6]
### Added
- Fire Ruby Designs Discord server link to README.
- Inner shadow to input elements.
- data-dtype field to input elements.

### Removed
- Remove border radius from input elements.
- Remove casts on input element values.

### Fixed
- Fix HTML tag syntax of currency fields.
- Fix career skill levels updating incorrectly.

## [0.1.5]
### Changed
- Update proper names of supported games.
- Refactor code formatting.

## [0.1.4]
### Added
- The public release of this system.

### Fixed
- Fix various one-off bugs.

## [0.1.3]
### Added
- Drag-and-drop sorting for all items.
- More accessibility.

### Changed
- Refactor formatting of HBS templates.
- Change header sizes for sheets.

### Fixed
- Fix name of Basic Tests for Glyphs.

## [0.1.2]
### Added
- Increment skill level button when advances are greater than or equal
  to zero.

### Changed
- Add callback to ystem settings to reload the world when modified.

### Fixed
- Fix career input fields from not focusing correctly.

## [0.1.1]
### Added
- Box shadow to input fields.
- Logic to prevent default event logic.
- Acknowledgments section to README.

### Changed
- Change formatting of README.

### Fixed
- Fix typo in README.
- Fix career skills not calculating correctly.

## [0.1.0]
### Added
- The initial private release of this system.

[Unreleased]: https://github.com/gmsshadow/fvtt-warlock/compare/v2.4.3...main
[2.4.3]: https://github.com/gmsshadow/fvtt-warlock/compare/v2.2.2...v2.4.3
[2.2.2]: https://github.com/gmsshadow/fvtt-warlock/compare/v1.0.0...v2.2.2
[0.3.10]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.9...v0.3.10
[0.3.9]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.8...v0.3.9
[0.3.8]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.7...v0.3.8
[0.3.7]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.6...v0.3.7
[0.3.6]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.5...v0.3.6
[0.3.5]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.4...v0.3.5
[0.3.4]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.3...v0.3.4
[0.3.3]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.2...v0.3.3
[0.3.2]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.1...v0.3.2
[0.3.1]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.3.0...v0.3.1
[0.3.0]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.2.1...v0.3.0
[0.2.1]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.2.0...v0.2.1
[0.2.0]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.9...v0.2.0
[0.1.9]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.8...v0.1.9
[0.1.8]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.7...v0.1.8
[0.1.7]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.6...v0.1.7
[0.1.6]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.5...v0.1.6
[0.1.5]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.4...v0.1.5
[0.1.4]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.3...v0.1.4
[0.1.3]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.2...v0.1.3
[0.1.2]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.1...v0.1.2
[0.1.1]: https://gitlab.com/azarvel/fvtt-warlock/-/compare/v0.1.0...v0.1.1
[0.1.0]: https://gitlab.com/azarvel/fvtt-warlock/-/releases/v0.1.0
